from app.models import TradeCandidate


class RiskService:
    """
    Hard rules. These must override AI recommendations.
    Tune only after paper-trading analysis.
    """

    MAX_RISK_PER_TRADE = 500.0
    MIN_LIQUIDITY_SCORE = 70.0

    def candidate_allowed(self, c: TradeCandidate) -> tuple[bool, list[str]]:
        reasons = []

        if c.max_loss > self.MAX_RISK_PER_TRADE:
            reasons.append(f"max_loss {c.max_loss:.2f} exceeds {self.MAX_RISK_PER_TRADE:.2f}")

        if c.liquidity_score < self.MIN_LIQUIDITY_SCORE:
            reasons.append(
                f"liquidity_score {c.liquidity_score:.0f} below {self.MIN_LIQUIDITY_SCORE:.0f}"
            )

        return (len(reasons) == 0, reasons)

    def filter_candidates(self, candidates: list[TradeCandidate]):
        approved = []
        rejected = []

        for c in candidates:
            ok, reasons = self.candidate_allowed(c)
            if ok:
                approved.append(c)
            else:
                rejected.append({"candidate_id": c.id, "reasons": reasons})

        return approved, rejected


risk_service = RiskService()
