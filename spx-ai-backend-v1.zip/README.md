# SPX AI Backend V1

FastAPI backend for the SPX AI Trading Dashboard.

## Important
This V1 uses DEMO SPX/options data by default. It is for development and paper-trading workflow testing only. It does not connect to live Robinhood SPX/options data.

## Features
- FastAPI API
- Demo SPX snapshot
- Demo indicators and levels
- Demo 0DTE strategy candidates
- Hard risk filter
- OpenAI Responses API analysis (optional)
- Safe fallback if no OpenAI API key is configured
- In-memory paper trading
- Base44-friendly CORS
- Render deployment config

## Run locally

1. Install Python 3.13.
2. Create a virtual environment:

```bash
python -m venv .venv
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

3. Install:
```bash
pip install -r requirements.txt
```

4. Copy environment file:
```bash
cp .env.example .env
```

5. Start:
```bash
uvicorn app.main:app --reload
```

6. Open:
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/api/health

## Important endpoints
- `GET /api/health`
- `GET /api/market/spx`
- `GET /api/market/indicators`
- `GET /api/market/levels`
- `GET /api/options/candidates`
- `GET /api/options/chain`
- `POST /api/ai/analyze`
- `POST /api/paper-trades`
- `GET /api/paper-trades/open`
- `POST /api/paper-trades/{trade_id}/close`
- `GET /api/analytics/summary`

## OpenAI
Set `OPENAI_API_KEY` in `.env` locally or as a Render environment variable.

Never commit `.env` or an API key to GitHub.

## Deploy to Render
Build command:
```text
pip install -r requirements.txt
```

Start command:
```text
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Health check:
```text
/api/health
```

After deploy, test:
```text
https://YOUR-SERVICE.onrender.com/docs
https://YOUR-SERVICE.onrender.com/api/health
```

## Base44
Use your Render URL as the API base URL.

Example:
```text
https://YOUR-SERVICE.onrender.com
```

Then Base44 can call:
```text
GET /api/market/spx
POST /api/ai/analyze
```

## Next milestone
Replace `app/services/market.py` demo provider with a real authorized SPX/options market-data provider and add PostgreSQL persistence.
