# GitHub + Render deployment instructions

## A. Create the GitHub repository

1. Sign in to GitHub.
2. Click **New repository**.
3. Repository name: `spx-ai-backend-v1`
4. Choose **Private** unless you intentionally want the code public.
5. Create repository.

## B. Upload with Git

Open Terminal in this project folder:

```bash
git init
git add .
git commit -m "Initial SPX AI FastAPI V1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/spx-ai-backend-v1.git
git push -u origin main
```

If GitHub asks you to authenticate, use GitHub's normal sign-in/token flow.

Never add `.env` to Git. `.gitignore` already excludes it.

## C. Deploy on Render

1. Sign in to Render.
2. Click **New +** → **Web Service**.
3. Connect GitHub.
4. Select `spx-ai-backend-v1`.
5. Configure:

- Runtime: Python
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Health check path: `/api/health`

6. Add environment variables:

```text
ENVIRONMENT=production
DEMO_MODE=true
OPENAI_MODEL=gpt-5.5
CORS_ORIGINS=*
```

Optional initially:
```text
OPENAI_API_KEY=your_key_here
```

Do NOT put quotes around environment variable values unless Render specifically requires them.

7. Deploy.

## D. Test your service

Render will create a URL similar to:

```text
https://spx-ai-backend-v1.onrender.com
```

Test:

```text
https://spx-ai-backend-v1.onrender.com/
https://spx-ai-backend-v1.onrender.com/api/health
https://spx-ai-backend-v1.onrender.com/docs
```

Swagger `/docs` lets you test all endpoints from your browser.

## E. Connect Base44

Tell Base44:

```text
API Base URL:
https://spx-ai-backend-v1.onrender.com
```

Map the dashboard to:

```text
GET /api/market/spx
GET /api/market/indicators
GET /api/market/levels
GET /api/options/candidates
POST /api/ai/analyze
POST /api/paper-trades
GET /api/paper-trades/open
GET /api/analytics/summary
```

For opening a paper trade, POST:

```json
{
  "candidate_id": "demo-bull-put-1",
  "contracts": 1
}
```

## F. Lock down CORS after Base44 is working

Once you know the exact production Base44 domain, change:

```text
CORS_ORIGINS=*
```

to:

```text
CORS_ORIGINS=https://YOUR-BASE44-DOMAIN
```

Then redeploy.

## G. Updating the app

Every time you change code locally:

```bash
git add .
git commit -m "Describe the update"
git push
```

With auto-deploy enabled, Render redeploys from your GitHub branch.

## H. V1 limitations

- Demo market data only.
- No live Robinhood SPX/options integration.
- Paper positions are stored in memory and reset when the server restarts.
- `/api/options/chain` is a placeholder.
- Analytics is a placeholder until PostgreSQL is added.
- Real-money execution is intentionally disabled.
